#include <iostream>
int main()
{
    int x; int y;
    std::cout << "Howdy Ags!"<<std::endl;
    return 0;
}
